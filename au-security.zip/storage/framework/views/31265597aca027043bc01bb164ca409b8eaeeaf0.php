
<?php $__env->startSection('page_title','Manage Job'); ?>
<?php $__env->startSection('managejob_selected','active'); ?>
<?php $__env->startSection('container'); ?>

<div class="row card card-body pt-2 pr-5 pb-5 pl-5">
    <h2 class="mb-2">Add Job</h2>
    <hr style="border-bottom:5px solid black;">
    <div class="col-lg-12">
        <?php if(session('message')!==null): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e(route('client.manage_job_process')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="requirement" class="control-label mb-1">Requirement</label>
                            <input id="requirement" value="<?php echo e($requirement); ?>" name="requirement" type="text"
                                aria-invalid="false" class="form-control" placeholder="Please enter number of guard">
                            <?php $__errorArgs = ['requirement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger" role="alert">
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <label for="in_time" style="text-align:center" class="control-label mb-1">Contract period</label>
                        <hr>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="join_date" class="control-label mb-1">Joining Date</label>
                                    <input id="join_date" value="<?php echo e($join_date); ?>" name="join_date" type="date"
                                        class="form-control" aria-invalid="false">
                                    <?php $__errorArgs = ['join_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="leave_date" class="control-label mb-1">Last date</label>
                                    <input id="leave_date" value="<?php echo e($leave_date); ?>" name="leave_date" type="date"
                                        class="form-control" aria-invalid="false">
                                    <?php $__errorArgs = ['leave_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="in_time" class="control-label mb-1">In Time</label>
                                    <input id="in_time" value="<?php echo e($in_time); ?>" name="in_time" type="datetime-local"
                                        class="form-control" aria-invalid="false">
                                    <?php $__errorArgs = ['in_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                    <label for="out_time" class="control-label mb-1">Out Time</label>
                                    <input id="out_time" value="<?php echo e($out_time); ?>" name="out_time" type="datetime-local"
                                        class="form-control" aria-invalid="false">
                                    <?php $__errorArgs = ['out_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger" role="alert">
                                            <?php echo e($message); ?>

                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                                </div>

                            </div>
                        </div>
                       


                        <div class="form-group">
                            <label for="location_address" class="control-label mb-1">Location Address</label>
                            <input id="location_address" value="<?php echo e($location_address); ?>" name="location_address"
                                type="text" class="form-control" aria-invalid="false" placeholder="Please enter address">
                            <?php $__errorArgs = ['location_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger" role="alert">
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="form-group">
                            <label for="city" class="control-label mb-1">City</label>
                            <input id="city" value="<?php echo e($city); ?>" name="city" type="text" class="form-control"
                                aria-invalid="false" placeholder="Please enter city">
                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger" role="alert">
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>
                        <div class="form-group">
                            <label for="pincode" class="control-label mb-1">Pincode</label>
                            <input id="pincode" value="<?php echo e($pincode); ?>" name="pincode" type="text" class="form-control"
                                aria-invalid="false" placeholder="Please enter pincode">
                            <?php $__errorArgs = ['pincode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-danger" role="alert">
                                    <?php echo e($message); ?>

                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        </div>

                        <div>
                            <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                Submit
                                <span id="payment-button-sending" style="display:none;">Sending…</span>
                            </button>
                        </div>
                        <input type="hidden" name="id" value="<?php echo e($id); ?>" />
                    </form>
                </div>
            </div>
        </div>

    </div>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('client/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev-work\my-git\au-security\resources\views/client/job_manage.blade.php ENDPATH**/ ?>