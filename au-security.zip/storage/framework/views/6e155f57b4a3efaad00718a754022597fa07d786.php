
<?php $__env->startSection('page_title','Dashboard'); ?>
<?php $__env->startSection('dashboard_selected','active'); ?>

<?php $__env->startSection('container'); ?>

<div class="row m-t-25">
    <a href="" class="col-sm-6 col-lg-6">
        <div class="overview-item overview-item--c1">
            <div class="overview__inner">
                <div class="overview-box clearfix text-center">
                    <div class="text text-center mb-5">
                        <div class="icon">
                            
                            <i class="fa fa-user-secret"></i>
                            <h2 style="fon t-size: 18px !important">Completed Jobs </h2>
                            <h2> 
                                0
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </a>
    <a href="" class="col-sm-6 col-lg-6">
        <div class="overview-item overview-item--c1">
            <div class="overview__inner">
                <div class="overview-box clearfix text-center">
                    <div class="text text-center mb-5">
                        <div class="icon">
                            <i class="zmdi zmdi-account-o"></i>
                            <h2 style="fon t-size: 18px !important">New Jobs</h2>
                            <h2>   
                                2
                            </h2>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </a>
    
 
     
  
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('guard/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev-work\my-git\au-security\resources\views/guard/dashboard.blade.php ENDPATH**/ ?>