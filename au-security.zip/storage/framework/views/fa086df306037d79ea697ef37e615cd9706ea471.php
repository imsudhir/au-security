
<?php $__env->startSection('page_title','My Jobs'); ?>
<?php $__env->startSection('myJobs_selected','active'); ?>
<?php $__env->startSection('container'); ?>
 
    <div class="row card card-body pt-2 pr-5 pb-5 pl-5">
        <h2 class="mb-2">Jobs details</h2>
     
        <div class="col-lg-12">
            <a class="btn btn-warning" href="<?php echo e(url('guard/myJobs')); ?>">
                < Back   
                 </a>
        <hr style="border-bottom:5px solid black;">

            <?php if(session('message')!==null): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            
        </div>
     

                <div class="container">
   
   
                    <div class="form-group">
                     <div class="form-group">
                      <label for="pwd">Client:</label>
                      <p><?php echo e($data->client_name); ?></p>
                    </div>
                    <div class="form-group">
                      <label for="pwd">Address:</label>
                      <p><?php echo e($data->location_address); ?></p>
                    </div>
                    <div class="form-group">
                      <label for="pwd">City:</label>
                      <p><?php echo e($data->city); ?></p>
                    </div><div class="form-group">
                      <label for="pwd">Pincode:</label>
                      <p><?php echo e($data->pincode); ?></p>
                    </div>
                    <div class="form-group">
                      <label for="pwd">In Time:</label>
                      <p><?php echo e($data->in_time); ?></p>
                    </div>
                    <div class="form-group">
                        <label for="pwd">Out Time:</label>
                        <p><?php echo e($data->out_time); ?></p>
                      </div>
                    </div>
                    
                     
                   
                   
                </div>
        
    </div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('guard/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev-work\au-security\resources\views/guard/jobdetails.blade.php ENDPATH**/ ?>