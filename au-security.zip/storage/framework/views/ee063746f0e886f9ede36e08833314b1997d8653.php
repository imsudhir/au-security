<?php echo e($slot); ?>

<?php /**PATH E:\sudhir\au-security\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>