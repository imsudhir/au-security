
<?php $__env->startSection('page_title','Guard'); ?>
<?php $__env->startSection('newjobs_selected','active'); ?>
    
<?php $__env->startSection('container'); ?>
 
    <div class="row card card-body pt-2 pr-5 pb-5 pl-5">
        <h2 class="mb-2">New Jobs</h2>

        <div class="col-lg-12">
        <hr style="border-bottom:5px solid black;">
            <?php if(session('message')!==null): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('jobmessage')!==null): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('jobmessage')); ?>

            </div>
            <?php endif; ?>
            
            
        </div>
        <table id="example" class="display responsive nowrap" style="width:100%">
            <thead>
                <tr>
                    <th widt h="2%">Id</th>
                    <th widt h="10%">Client Name</th>
                    <th widt h="8%" class="text-center">No of Jobs</th>
                    <th wid th="2%" class="text-center">In time </th>
                    <th widt h="2%" class="text-center">Out time</th>
                    <th w idth="30%" class="text-center">Address</th>
                    <th wi dth="30%" class="text-center">City</th>
                    <th wid th="30%" class="text-center">Pincode</th>
                  
                    <th width="40%" class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!-- <?php echo e(empty(array_search(session('GUARD_IDaaa'),json_decode($list->accepted_by)))); ?> -->
             <?php if(empty(array_search(session('GUARD_ID'),json_decode($list->accepted_by)))): ?>
                 <tr>
                    <td><?php echo e($list->id); ?></td>
                    <td><?php echo e($list->client_name); ?></td>
                    <td><?php echo e($list->requirement); ?></td>
                    <td><?php echo e($list->in_time); ?></td>
                    <td><?php echo e($list->out_time); ?></td>
                    <td><?php echo e($list->location_address); ?></td>
                    <td><?php echo e($list->city); ?></td>
                    <td><?php echo e($list->pincode); ?></td>
                    <td class="text-center">
                        <div class="btn-group" role="group" aria-label="Basic example">
                           <?php if($list->requirement_accepted == $list->requirement): ?>
                           <a class="btn btn-warning" disabled >
                          Job filled    
                           </a>
                           <?php endif; ?>
                           <?php if($list->requirement_accepted < $list->requirement): ?>
                           <a class="btn btn-warning" href="<?php echo e(url('guard/newjobs/accept/')); ?>/<?php echo e($list->id); ?>">
                          Accept now
                           </a>
                           <?php endif; ?>
                           <a class="btn btn-warning" href="<?php echo e(url('guard/job-details')); ?>/<?php echo e($list->id); ?>">
                            View details     
                             </a>
                      </div>
                    </td>
                 
                </tr>
             <?php endif; ?>
               
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </tbody>
        </table>
    </div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('guard/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev-work\my-git\au-security\resources\views/guard/newJobs.blade.php ENDPATH**/ ?>