
<?php $__env->startSection('page_title','Guard'); ?>
<?php $__env->startSection('requirements_selected','active'); ?>
    
<?php $__env->startSection('container'); ?>
 
    <div class="row card card-body pt-2 pr-5 pb-5 pl-5">
        <h2 class="mb-2">Jobs</h2>
        <hr style="border-bottom:5px solid black;">

        <div class="col-lg-12">
            <?php if(session('message')!==null): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            
        </div>
        <table id="example" class="display responsive nowrap" style="width:100%">
            <thead>
                <tr>
                    <th widt h="5%">Id</th>
                    <th widt h="10%">Client Name</th>
                    <th widt h="8%" class="text-center">No. of jobs</th>
                    <th widt h="5%" class="text-center">In time </th>
                    <th widt h="2%" class="text-center">Out time</th>
                    <th widt h="30%" class="text-center">Address</th>
                    <th widt h="40%" class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($list->id); ?></td>
                    <td><?php echo e($list->client_name); ?></td>
                    <td><?php echo e($list->requirement); ?></td>
                    <td><?php echo e($list->in_time); ?></td>
                    <td><?php echo e($list->out_time); ?></td>
                    <td><?php echo e($list->location_address); ?></td>
                    <td>
                        <div class="btn-group" role="group" aria-label="Basic example">
                         <a class="btn btn-primary" href="<?php echo e(url('admin/guard/view_details')); ?>/<?php echo e($list->id); ?>">
                            View     
                        </a>
                       
                           <?php if($list->approve == 1): ?>
                           <a class="btn btn-primary" href="<?php echo e(url('admin/newjobs/approve/0')); ?>/<?php echo e($list->id); ?>">
                             Approved    
                           </a>
                           <a class="btn btn-primary" href="<?php echo e(url('admin/newjobs/broadcast/')); ?>/<?php echo e($list->id); ?>">
                            Brodcast    
                          </a>
                           <?php elseif($list->approve == 0): ?>
                           <a class="btn btn-warning" href="<?php echo e(url('admin/newjobs/approve/1')); ?>/<?php echo e($list->id); ?>">
                          Not Approved     
                           </a>
                           <?php endif; ?>
                          
                      </div>
                    </td>
                 
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </tbody>
        </table>
    </div>
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev-work\au-security\resources\views/admin/requirement.blade.php ENDPATH**/ ?>