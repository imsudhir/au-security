
<?php $__env->startSection('page_title','Guard'); ?>
<?php $__env->startSection('guard_selected','active'); ?>
    
<?php $__env->startSection('container'); ?>

<h2 class="mb-2">Guard Details</h2>  <a href="<?php echo e(url('admin/guard')); ?>" class="btn btn-md btn-info mb-3">Back</a> 

    
<div class="card">
    <div class="card-body">
      <div class="row">
          <div class="col-lg-6">
            <b>Name:</b> <?php echo e($data->name); ?>    
          </div>
          <div class="col-lg-6">
            <b>Profile Image:</b> <img src='<?php echo e($data->profile_image); ?>'>    
           </div>
           <div class="col-lg-6">
            <b>Email:</b> <?php echo e($data->email); ?>    
           </div>
         <div class="col-lg-6">
            <b>Mobile: </b><?php echo e($data->mobile); ?>    
        </div>
        <hr style="border: 2px solid black; width:100%;">
        <div class="col-lg-12">
            <b>Address: </b><?php echo e($data->address); ?>    
        </div>
        <div class="col-lg-6">
            <b>City: </b><?php echo e($data->city); ?>    
        </div>
        <div class="col-lg-6">
            <b>Pincode: </b><?php echo e($data->pincode); ?>    
        </div>
        <div class="col-lg-6">
            <b>Availability: </b><?php echo e($data->availability_time); ?>    
        </div>
        <div class="col-lg-6">
            <b>Verify Status: </b><?php echo e($data->active_status); ?>    
        </div>
        <div class="col-lg-6">
            <b>Active Status: </b><?php echo e($data->verify_status); ?>    
        </div>
        <div class="col-lg-6">
            <b>Login Credentials: </b><?php echo e($data->login_id && $data->login_password? 'created':'n/a'); ?>    
        </div>
      </div>
    </div>
  </div>
  <table id="table_id" class="display">
    <thead>
        <tr>
            <th>Column 1</th>
            <th>Column 2</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Row 1 Data 1</td>
            <td>Row 1 Data 2</td>
        </tr>
        <tr>
            <td>Row 2 Data 1</td>
            <td>Row 2 Data 2</td>
        </tr>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev-work\my-git\au-security\resources\views/admin/view_details.blade.php ENDPATH**/ ?>