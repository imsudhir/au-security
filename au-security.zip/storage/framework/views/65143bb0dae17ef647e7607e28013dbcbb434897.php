
<?php if($details['brodcast']==1): ?>
<h2>New jobs available</h2>
<b>Total Jobs: </b><?php echo e($details['totaljobs']); ?><br>
<b>Apply here: </b><?php echo e($details['link']); ?>


<br>
<br>
Thanks,
<br>
<br>
<?php echo e(config('app.name')); ?>

<?php else: ?>
    
<h2>Your Login Creentials</h2>
<img src="https://cdn.templates.unlayer.com/assets/1597209249736-woman-traveler-looking-caldera-from-fira-thera-santorini-island-greece-tourism-traveling-vacation-concept_106029-1429.jpg">
<b>userid: </b><?php echo e($details['userid']); ?><br>
<b>password: </b><?php echo e($details['password']); ?>


<br>
<br>
Thanks,
<br>
<br>
<?php echo e(config('app.name')); ?>

<?php endif; ?>


<?php /**PATH E:\sudhir\au-security\resources\views/emails/auSendMail.blade.php ENDPATH**/ ?>