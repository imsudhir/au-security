
<?php $__env->startSection('page_title','Guard'); ?>
<?php $__env->startSection('guard_selected','active'); ?>

<?php $__env->startSection('container'); ?>
<h2 class="mb-2">Guard</h2>
<div class="row card card-body p-4">

    <div class="col-lg-12">
        <?php if(session('message')!==null): ?>
            <div class="alert alert-success text-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?>

    </div>
    <table id="example" class="display responsive nowrap" style="width:100%">
        <thead>
            <tr>
                <th>Id</th>
                <th>NAME</th>
                <th class="text-center">EMAIL</th>
                <th class="text-center">PHONE NUMBER</th>
                <th class="text-center">ADDRESS</th>
                <th class="text-center">STATE</th>
                <th class="text-center">SUBURB/CITY</th>
                <th class="text-center">ZIP/POSTAL CODE</th>
                <th class="text-center">RESUME</th>
                <th class="text-center">ADDITIONAL INFORMATION</th>
                <th class="text-center">ACTION</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($list->id); ?></td>
                    <td><?php echo e($list->f_name.' '.$list->l_name); ?></td>
                    <td><?php echo e($list->email); ?></td>
                    <td><?php echo e($list->mobile); ?></td>
                    <td><?php echo e($list->address); ?></td>
                    <td><?php echo e($list->state); ?></td>
                    <td><?php echo e($list->city); ?></td>
                    <td><?php echo e($list->pincode); ?></td>
                    <td>
                        
                           <?php if($list->resume): ?>
                            <a class="btn btn-primary" href="<?php echo e(url('storage/media').'/'.$list->resume); ?>" download >download</button>
                           <?php endif; ?>
                        
                    </td>
                    <td><?php echo e($list->additional_information); ?></td>
                  <td>
                    <div class="btn-group" role="group" aria-label="Basic example">
                            <!-- <a class="btn btn-primary"
                                href="<?php echo e(url('admin/guard/view_details')); ?>/<?php echo e($list->id); ?>"
                                data-toggle="tooltip" data-placement="top" title="View details!">
                                <i class="fa fa-eye" aria-hidden="true"></i>

                            </a> -->

                            <?php if($list->verify_status == 1): ?>
                                <a class="btn btn-primary"
                                    href="<?php echo e(url('admin/guard/verify_status/0')); ?>/<?php echo e($list->id); ?>"
                                    data-toggle="tooltip" data-placement="top" title="Verified!">
                                    <i class="fa fa-check" aria-hidden="true"></i>

                                </a>
                                <?php if($list->active_status == 1): ?>
                                    <a class="btn btn-primary"
                                        href="<?php echo e(url('admin/guard/active_status/0')); ?>/<?php echo e($list->id); ?>">
                                        Active
                                    </a>
                                    <a class="btn btn-warning"
                                    href="<?php echo e(url('admin/guard/send_guard_credentials')); ?>/<?php echo e($list->id); ?>"
                                    data-toggle="tooltip" data-placement="top" title="Send login details!">
                                    <i class="fa fa-paper-plane" aria-hidden="true"></i>
                                </a>
                                <?php elseif($list->active_status == 0): ?>
                                    <a class="btn btn-warning"
                                        href="<?php echo e(url('admin/guard/active_status/1')); ?>/<?php echo e($list->id); ?>">
                                        Deactive
                                    </a>
                                
                                <?php endif; ?>
                            <?php elseif($list->verify_status == 0): ?>
                                <a class="btn btn-warning"
                                    href="<?php echo e(url('admin/guard/verify_status/1')); ?>/<?php echo e($list->id); ?>"
                                    data-toggle="tooltip" data-placement="top" title="Not verified">
                                    <i class="fas fa-times"></i>
                                </a>
                            <?php endif; ?>




                        </div>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev-work\my-git\au-security\resources\views/admin/guard.blade.php ENDPATH**/ ?>