
<?php $__env->startSection('page_title','product'); ?>
<?php $__env->startSection('product_selected','active'); ?>
    
<?php $__env->startSection('container'); ?>

<div class="row card card-body pt-2 pr-5 pb-5 pl-5">
        <h2 class="mb-2">Products</h2>
        <hr style="border-bottom:5px solid black;">

        <div class="col-lg-12">
            <?php if(session('message')!==null): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            
        </div>
        <table id="example" class="display responsive nowrap" style="width:100%">
            <thead>
                <tr>
                            <th>Id</th>
                            <th class="text">Name</th>
                            <th class="text-center">Brand</th>
                            <th class="text-center">Short desc</th>
                            <th class="text-center">Long desc</th>
                            <th class="text-center">Tech spec</th>
                            <th class="text-center">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                <td><?php echo e($list->id); ?></td>
                            <td><?php echo e($list->name); ?></td>
                            <td><?php echo e($list->brand); ?></td>
                            <td><?php echo e($list->short_desc); ?></td>
                            <td><?php echo e($list->long_desc); ?></td>
                            <td><?php echo e($list->tech_spec); ?></td>
                    <td>
                    <a href="<?php echo e(url('admin/product/manage_product')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-success">Edit</button>    
                                   </a>
                               
                                   <?php if($list->status == 1): ?>
                                   <a href="<?php echo e(url('admin/product/status/0')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-primary">Active</button>    
                                   </a>
                                   <?php elseif($list->status == 0): ?>
                                   <a href="<?php echo e(url('admin/product/status/1')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-warning">Deactive</button>    
                                   </a>
                                   <?php endif; ?>
                                   <a href="<?php echo e(url('admin/product/delete')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-danger">Delete</button>    
                                   </a>
                                    </td>
                 
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </tbody>
        </table>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\dev-work\my-git\au-security\resources\views/admin/products.blade.php ENDPATH**/ ?>