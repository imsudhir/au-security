
<?php $__env->startSection('page_title','Guard'); ?>
<?php $__env->startSection('guard_selected','active'); ?>
    
<?php $__env->startSection('container'); ?>
<?php if($userRole==2): ?>
<h2 class="mb-2">Guard</h2>
    <div class="row card card-body p-4">

        <div class="col-lg-12">
            <?php if(session('message')!==null): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            
        </div>
        <table class="table" id="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th class="text-right">Email</th>
                    <th class="text-right">Mobile</th>
                    <th class="text-right">Address</th>
                    <th class="text-right">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($list->id); ?></td>
                    <td><?php echo e($list->name); ?></td>
                    <td><?php echo e($list->email); ?></td>
                    <td><?php echo e($list->mobile); ?></td>
                    <td><?php echo e($list->address); ?>                    
                    </td>
                    <td>
                        <div class="btn-group" role="group" aria-label="Basic example">
                         <a class="btn btn-primary" href="<?php echo e(url('admin/guard/view_details')); ?>/<?php echo e($list->id); ?>">
                            View     
                        </a>
                       
                           <?php if($list->verify_status == 1): ?>
                           <a class="btn btn-primary" href="<?php echo e(url('admin/guard/verify_status/0')); ?>/<?php echo e($list->id); ?>">
                             Verified    
                           </a>
                           <?php elseif($list->verify_status == 0): ?>
                           <a class="btn btn-warning" href="<?php echo e(url('admin/guard/verify_status/1')); ?>/<?php echo e($list->id); ?>">
                          Not Verified     
                           </a>
                           <?php endif; ?>
                           <?php if($list->active_status == 1): ?>
                           <a class="btn btn-primary" href="<?php echo e(url('admin/guard/active_status/0')); ?>/<?php echo e($list->id); ?>">
                            Active   
                           </a>
                           <?php elseif($list->active_status == 0): ?>
                           <a class="btn btn-warning" href="<?php echo e(url('admin/guard/active_status/1')); ?>/<?php echo e($list->id); ?>">
                             Deactive   
                           </a>
                           <?php endif; ?>

                           <a class="btn btn-warning" href ="<?php echo e(url('admin/guard/send_guard_credentials')); ?>/<?php echo e($list->id); ?>">
                             Send login data
                         </a>
                        
                      </div>
                    </td>
                 
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
            </tbody>
        </table>
    </div>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sudhir\au-security\resources\views/admin/guard.blade.php ENDPATH**/ ?>