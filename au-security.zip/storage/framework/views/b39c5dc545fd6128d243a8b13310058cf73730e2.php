<!DOCTYPE html>
<html>
<head>
    <title>au-security</title>
</head>
<body>
    <h1><?php echo e($details['title']); ?></h1>
    <p><?php echo e($details['body']); ?></p>
   
    <p>Thank you</p>
</body>
</html><?php /**PATH E:\sudhir\au-security\resources\views/emails/myMail.blade.php ENDPATH**/ ?>