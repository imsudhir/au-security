
<?php $__env->startSection('page_title','Category'); ?>
<?php $__env->startSection('category_selected','active'); ?>
    
<?php $__env->startSection('container'); ?>
<h2 class="mb-2">Category</h2>
<a href="<?php echo e(url('admin/category/manage_category')); ?>"> <button type="button" class="btn btn-primary">
    Add Category</button>
</a>
    <div class="row mt-3">

        <div class="col-lg-12">
            <?php if(session('message')!==null): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('message')); ?>

            </div>
            <?php endif; ?>
            <div class="table-responsive table--no-card m-b-30">
                <table class="table table-borderless table-striped table-earning">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>category Name</th>
                            <th class="text-right">Category Slug</th>
                            <th class="text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($list->id); ?></td>
                            <td><?php echo e($list->category_name); ?></td>
                            <td><?php echo e($list->category_slug); ?></td>
                            <td>
                                
                                   <a href="<?php echo e(url('admin/category/manage_category')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-success">Edit</button>    
                                   </a>
                                   <?php if($list->status == 1): ?>
                                   <a href="<?php echo e(url('admin/category/status/0')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-primary">Active</button>    
                                   </a>
                                   <?php elseif($list->status == 0): ?>
                                   <a href="<?php echo e(url('admin/category/status/1')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-warning">Deactive</button>    
                                   </a>
                                   <?php endif; ?>
                                   
                                   <a href="<?php echo e(url('admin/category/delete')); ?>/<?php echo e($list->id); ?>">
                                    <button type="button" class="btn btn-danger">Delete</button>    
                                   </a>
                                    </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
     
    </div>
 
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\sudhir\Laravel-ecom\ecom\resources\views/admin/category.blade.php ENDPATH**/ ?>